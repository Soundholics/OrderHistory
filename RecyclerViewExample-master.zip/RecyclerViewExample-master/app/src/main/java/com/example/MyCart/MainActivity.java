package com.example.MyCart;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);



        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        MyData[] MyData = new MyData[]{
                new MyData("Avengers","2019 film",R.drawable.avenger),
                new MyData("Venom","2018 film",R.drawable.venom),
                new MyData("Batman Begins","2005 film",R.drawable.batman),
                new MyData("Jumanji","2019 film",R.drawable.jumanji),
                new MyData("Good Deeds","2012 film",R.drawable.good_deeds),
                new MyData("Hulk","2003 film",R.drawable.hulk),
                new MyData("Avatar","2009 film",R.drawable.avatar),
        };

        MyAdapter myAdapter = new MyAdapter(MyData,MainActivity.this);
        recyclerView.setAdapter(myAdapter);

    }
}
