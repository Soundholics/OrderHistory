package com.example.myorders;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RatingBar;
import android.widget.TextView;
import android.widget.Toast;

public class Rate extends AppCompatActivity {

    TextView tvFeedback;
    RatingBar rbStars;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_rate);

        tvFeedback = findViewById(R.id.tvFeedback);
        rbStars = findViewById(R.id.rbStars);
        Button send = findViewById(R.id.btnSend);

        rbStars.setOnRatingBarChangeListener(new RatingBar.OnRatingBarChangeListener() {
            @Override
            public void onRatingChanged(RatingBar ratingBar, float rating, boolean fromUser) {
                if(rating==0)
                {
                    tvFeedback.setText("0");
                }
                else if(rating==0.5)
                {
                    tvFeedback.setText("0.5");
                }
                else if(rating==1)
                {
                    tvFeedback.setText("1");
                }
                else if(rating==1.5)
                {
                    tvFeedback.setText("1.5");
                }
                else if(rating==2)
                {
                    tvFeedback.setText("2");
                }
                else if(rating==2.5)
                {
                    tvFeedback.setText("2.5");
                }
                else if(rating==3)
                {
                    tvFeedback.setText("3");
                }
                else if(rating==3.5)
                {
                    tvFeedback.setText("3.5");
                }
                else if(rating==4)
                {
                    tvFeedback.setText("4");
                }
                else if(rating==4.5)
                {
                    tvFeedback.setText("4.5");
                }
                else if(rating==5)
                {
                    tvFeedback.setText("5");
                }
                else
                {

                }
            }
        });

        send.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Toast.makeText(Rate.this, "Feedback has been received", Toast.LENGTH_SHORT).show();
            }
        });
    }
}