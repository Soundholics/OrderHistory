package com.example.myorders;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

public class Adapter extends RecyclerView.Adapter<Adapter.ViewHolder> {

    Data[] myMovieData;
    MainActivity context;


    public Adapter(Data[] myMovieData,MainActivity activity) {
        this.myMovieData = myMovieData;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.user_item,parent,false);
        ViewHolder viewHolder = new ViewHolder(view);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final Data myMovieDataList = myMovieData[position];
        holder.textViewName.setText(myMovieDataList.getMovieName());
        holder.textViewDate.setText(myMovieDataList.getMovieDate());
        holder.movieImage.setCardElevation(myMovieDataList.getMovieImage());

        holder.itemView.findViewById(R.id.clickToRate).setOnClickListener(view-> context.onRate(myMovieDataList));
    }

    @Override
    public int getItemCount() {
        return myMovieData.length;
    }
    public interface orderData
    {
        public void onRate(Data data);
    }


    public class ViewHolder extends RecyclerView.ViewHolder{
        CardView movieImage;
        TextView textViewName;
        TextView textViewDate;
       // View itemView;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
           // this.itemView = itemView;
            movieImage = itemView.findViewById(R.id.movie_item_list);
            textViewName = itemView.findViewById(R.id.textName);
            textViewDate = itemView.findViewById(R.id.textdate);


        }
    }

}

