package com.example.myorders;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;

public class MainActivity extends AppCompatActivity implements Adapter.orderData {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = (RecyclerView)findViewById(R.id.recycle);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        Data[] myMovieData = new Data[]{
                new Data("Avengers","2019 film",R.drawable.avenger),
                new Data("Venom","2018 film",R.drawable.venom),
                new Data("Batman Begins","2005 film",R.drawable.batman),
                new Data("Jumanji","2019 film",R.drawable.jumanji),
                new Data("Good Deeds","2012 film",R.drawable.good_deeds),
                new Data("Hulk","2003 film",R.drawable.hulk),
                new Data("Avatar","2009 film",R.drawable.avatar),
        };

        Adapter myMovieAdapter = new Adapter(myMovieData,MainActivity.this);
        recyclerView.setAdapter(myMovieAdapter);

    }

    @Override
    public void onRate(Data data) {
        Intent intent = new Intent(this, Rate.class);
        startActivity(intent);
    }
}